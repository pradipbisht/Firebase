import React from "react";

function AdminDashboard() {
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <div className="md:w-64 bg-gray-500"></div>
    </div>
  );
}

export default AdminDashboard;
