import React from "react";

function DashContent() {
  return <div>DashContent</div>;
}

export default DashContent;
